# Autoevaluación técnica de la implementación

Esta autoevaluación usa una rúbrica de 5.0 construida a partir de los requisitos
del enunciado del Proyecto 13 y criterios normales de calidad de implementación.

| Criterio | Peso | Estado |
|---|---:|---|
| FIFO, LRU y OPT funcionales | 1.20 | Completo |
| Simulación y medición de fallos | 0.80 | Completo |
| Comparación online vs OPT | 0.70 | Completo |
| Experimentos reproducibles | 0.60 | Completo |
| Análisis de resultados y gráficas | 0.50 | Completo |
| Calidad de código y modularidad | 0.40 | Completo |
| Pruebas y validación | 0.40 | Completo |
| Interfaz y facilidad de demostración | 0.30 | Completo |
| Documentación de ejecución | 0.10 | Completo |

## Nota técnica estimada de la implementación: 5.0 / 5.0

### Evidencias

- FIFO, LRU y OPT están implementados por separado.
- Se registran hits, misses, reemplazos, hit rate y miss rate.
- Se calcula el ratio empírico frente a OPT.
- Se ejecutan experimentos con múltiples capacidades y repeticiones.
- Se soportan secuencias uniformes, con localidad temporal y cíclicas.
- Se soportan semillas para reproducibilidad.
- Se generan CSV y gráficas.
- Se incluye la anomalía de Belady.
- Existen pruebas automatizadas.
- La interfaz Streamlit permite demostrar el proyecto sin depender de la consola.
- Se conserva una versión CLI para validación adicional.

## Importante

Esta nota es una estimación técnica de la implementación. La calificación final
del curso depende también del informe y de la exposición.
